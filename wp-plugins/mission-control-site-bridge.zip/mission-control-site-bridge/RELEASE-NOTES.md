# Mission Control Site Bridge 1.6.0

Prepared: 29 October 2026. Based on the PHP file supplied in `mission-control-site-bridge(4).zip`.

## මුලින් කියවන්න

මේ ZIP එක install කළ හැකි edited plugin build එකයි. Live client site එකකට දාන්න පෙර staging site එකක පහත checks කරන්න. Code එක වෙනස් කර PHP syntax, real WordPress/database integration, fixture-plugin update/activation සහ concurrency tests කර ඇත. එයින් සියලු hosting environments, third-party plugins හෝ multisite configurations සඳහා certification එකක් අදහස් නොවේ.

**Update කළ පසු remote writes නැවත configure කළ යුතුයි.** Settings → MC Site Bridge තුළ service administrator කෙනෙකු තෝරා, අවශ්‍ය scopes tick කර, remote writes enable කර Save කරන්න. HTTPS පිටුපස WordPress `is_ssl()` නිවැරදිව ක්‍රියා කළ යුතුයි.

**Blog create requests වල `idempotency_key` අනිවාර්යයි.** Dashboard එකට පහත compatibility changes අවශ්‍යයි. `server.ts` ලබාදී නොතිබුණු නිසා ඒ file එක මේ ZIP එකේ වෙනස් කර නැත.

## Installation and rollback

1. Back up the WordPress database and current plugin directory. Keep the old ZIP for emergency recovery, not routine production use.
2. On staging, upload this ZIP via Plugins → Add New → Upload Plugin and replace the existing bridge. The directory and main filename are unchanged.
3. Visit Settings → MC Site Bridge. Choose an explicit administrator who belongs to the site. There is no automatic first-admin fallback.
4. Select only necessary scopes: plugin maintenance, SEO editing, and/or blog publishing. Enable remote writes and save. Existing write settings alone do not bypass the 1.6.0 review gate.
5. Keep the existing site secret or rotate it in WordPress and the dashboard together. Never send it in a URL/body or application logs. Configuration-file secrets are fully masked in the settings UI.
6. Verify HTTPS through the real proxy/CDN path. If TLS terminates at a proxy, configure WordPress at the server level using verified proxy identity; do not trust arbitrary forwarded headers.
7. Deploy dashboard changes below, then run the staging acceptance checklist.
8. Roll out one site at a time. Confirm the authenticated `/status` response reports `bridge_version: 1.6.0` and test a separate fresh request after maintenance.

If needed, disable remote writes first and restore a known backup through WordPress/SFTP. New audit/rate tables and job/snapshot records are retained; this build does not delete them on deactivation. Restoring the old PHP also restores its old security weaknesses. A filesystem rollback alone does not undo already-published posts or SEO edits.

## Changes implemented

### Authentication and authority

- Header-only secret authentication retained; bearer parsing anchored to the whole header.
- Valid credentials remain usable despite invalid attempts from the same proxy IP.
- Valid authenticated requests require WordPress to recognise HTTPS.
- Explicit configured service administrator required; invalid/missing users fail closed. Execution identity is restored after each write and SEO-read handler.
- Site-configured write scopes enforced for `/update-plugin`, `/activate-plugin`, `/update-seo`, and `/create-blog-post`.
- Writes default off and require an explicit settings review for this version.
- Draft/SEO reads require the configured service user's capabilities; individual posts are checked before inclusion.

Scopes constrain this site's **shared bridge credential**. They are not separate per-user or per-token credentials. `X-MC-Actor` is an unverified display label; verified audit attribution is the designated service account. Each site should have its own secret. Human authentication, tenant isolation, permissions, secret storage and request signing/replay controls in the dashboard remain the dashboard's responsibility.

### Rate limits

- Dedicated installation-wide numeric counter table, with one atomic SQL upsert per invalid attempt.
- First two invalid attempts return 403; the third and subsequent attempts return 429 within the fixed 30-minute window.
- Counter does not reset on valid authentication.
- Cleanup deletes only expired rows, in batches of at most 100.
- Storage failure denies invalid authentication with 503.
- `REMOTE_ADDR` remains the rate-limit identity. Behind a shared proxy this groups clients, so valid keys deliberately bypass invalid-key lockouts. This is not volumetric DDoS protection; use appropriate edge controls too.

### Maintenance locking

- Installation-wide bridge lock serializes bridge update/activation and content-write requests.
- Exact binary compare-and-swap for renewal/release, owner tokens, and successful same-value renewal.
- **No automatic takeover merely because a lease expired.** A slow worker cannot be overlapped by another bridge worker based on elapsed time alone.
- Renewal failure propagates as an upgrader error. Filter removal and lock release are handled through `finally` on normal/caught exit paths.
- A hard worker termination can leave a durable lock; manual reconciliation is intentional. No automatic shutdown handler erases evidence of an uncertain operation.
- Never modifies `.maintenance` itself and never rewrites active-plugin lists to restore target or unrelated plugins.

This is a bridge lock, **not a universal lock over WordPress admin, WP-CLI, hosting tools or third-party updaters**. Schedule bridge maintenance so those other writers do not run concurrently. Do not claim the bridge can prevent every external updater race. If universal coordination is required, the hosting/control plane must enforce it.

### Idempotency and blog creation

- Requires a 16–128 character key containing ASCII letters, digits, underscore or hyphen; conflicting body/header keys are rejected.
- Reservations scoped by blog ID, operation and key; payload hash rejects key reuse with a different payload.
- Atomic reservation and owner-value-checked completion. Parallel requests cannot both own the same reservation.
- Existing in-progress, malformed or ambiguous state cannot fall through to post creation, even when old.
- Legacy unscoped reservations block reuse pending investigation.
- Completion recorded only after post insertion, metadata verification and tag persistence.
- SEO metadata uses slashing plus readback verification. Post data is slashed correctly for core storage.
- Retrying a completed request returns the original post if accessible, even if its current status has since changed.

This provides conservative deduplication, **not an absolute exactly-once transaction across WordPress hooks and external systems**. A crash after post insertion but before durable linkage/completion requires reconciliation; the request remains blocked to avoid a duplicate. Do not retry an ambiguous publication with a new key.

### SEO, schema and snapshots

- Rejects non-object JSON, unknown fields, invalid field types, oversized bodies (1 MiB), non-integer post IDs, non-boolean flags and invalid tag arrays.
- Schema size is capped at 200,000 bytes and decoded depth at 32; root must be an object or array of objects. Schema string whitespace counts toward the byte limit.
- All field/schema validation happens before content mutation.
- Unique operation-specific snapshot is saved and read back before SEO changes. Missing and empty metadata remain distinct.
- Native titles remain unchanged unless explicitly requested. Native-title writes and all SEO metadata are verified after saving.
- Schema output preserves HEX escaping against script-tag breakout.
- Database/hook failures may produce partial changes. Errors include an operation ID; inspect the corresponding snapshot before deciding what to restore. This is **not** an automatic all-or-nothing transaction or automatic rollback service.

### Audit trail and version reporting

- Append-only audit rows replace read/modify/write option-array logging, preventing concurrent log overwrites.
- No `mbstring` dependency in the bridge audit writer.
- Logs store bounded target/label, action, status, service user ID, IP, timestamp and operation ID. Arbitrary payloads and raw error details are not stored.
- Audit storage must accept a start event before remote mutation proceeds. Final logging can still fail after a successful operation; the start event identifies an incomplete audit sequence.
- Latest 100 rows are available to the settings view (latest 10 displayed). Rows are retained rather than silently pruned; set an operational retention/export policy.
- Upgrade reports actual current activation flags. Unexpected target versions or activation changes return `verification_pending`.
- `updated` means the expected advancing version was installed, **not that the newly loaded plugin has passed runtime health tests**. `health_verified` is explicitly false.
- An authoritative core `no_update` entry returns `already_up_to_date` without running the upgrader. Missing update metadata returns an error, not false success.

## Dashboard changes required (`server.ts` not included)

1. Minimum supported bridge version for mutating operations: **1.6.0**. Use semantic version comparison, not lexicographic strings. Block missing/malformed/older versions.
2. Use the existing routes under `/wp-json/mc-bridge/v1/`; blog route remains **`/create-blog-post`**.
3. Send a real JSON object and `Content-Type: application/json`. Unknown fields are rejected. `post_id` is a positive JSON integer, and booleans must be JSON `true`/`false`.
4. Persist one idempotency key **before** sending a new blog job. Reuse that same key and exact payload on transport retries. A UUID is suitable. Do not create a new key on each HTTP attempt.
5. Use `X-MC-Bridge-Key` or `Authorization: Bearer`; HTTPS certificate verification must stay enabled. Redact these headers from logs.
6. Handle 400 validation failures, 403 disabled/unauthorised operations, 409 pending/conflicting operations, 429 invalid-key lockouts, and 503 storage/update-check failures distinctly.
7. On `operation_interrupted`, do not assume no changes happened. Store the operation ID and investigate. `verification_pending` is not success.
8. After plugin update, make a fresh authenticated `/status` request and check the target version/scope, then separately verify the site and relevant functionality. A successful same-request version response is insufficient.
9. Preserve site-level distributed scheduling if multiple dashboard server instances exist; an in-process mutex alone is not distributed coordination.
10. Restrict server-side destination URLs to registered sites, validate redirects/DNS and block internal/metadata targets as appropriate. Never forward site secrets to arbitrary redirect hosts. These server-side protections cannot be implemented by this PHP ZIP.

Example blog payload (keep the UUID unchanged for retries of this job):

```json
{
  "title": "Example article",
  "content": "<p>Approved article content.</p>",
  "status": "draft",
  "meta_title": "Example article title",
  "meta_description": "Example article description.",
  "focus_keyword": "example article",
  "tags": ["Example"],
  "idempotency_key": "f74ccbc1-b31a-4f14-8e1f-378edc3139b6"
}
```

For SEO edits, supported fields are `post_id`, `post_title`, `meta_title`, `meta_description`, `focus_keyword`, `update_post_title`, and `schema_json`. For activation: `slug`, `network_wide`. For updates: `slug` only. For blog creation: the fields in the example above. Schema is edited through `/update-seo`, not an ignored field in blog creation.

## Operator reconciliation

### Orphan maintenance lock

1. Disable new bridge writes and pause dashboard jobs.
2. Verify the original PHP worker/update process has stopped. Inspect plugin files, maintenance state, core logs and database state. A timestamp alone is insufficient.
3. Inspect the `_mc_bridge_upgrade_lock` row in the installation's **base-prefix options table**. Preserve its exact value and token in the incident record.
4. Only after confirming no worker is still active, have the operator delete that exact row with a prepared comparison against the full previous value, or call the owner-checked release helper from trusted local administration using the inspected token. Never expose a public unlock endpoint.
5. Verify site/plugin state before re-enabling writes. Do not automatically delete `.maintenance` as part of this procedure.

### Interrupted blog operation

Inspect the `_mc_job_…` row in the same base-prefix options table and any post metadata `_mc_idempotency_hash` referencing its option name. Search posts/time/author if the crash happened before that metadata was saved. Keep pending jobs blocked until the outcome is established. Do not delete pending records solely because they are old. Legacy `_mc_idem_…` records require the same care.

### SEO snapshot

The returned `snapshot_key` or operation ID identifies `_mc_seo_snapshot_<operation_id>` in that post's metadata. Compare current values with the intended job and later admin changes before restoring fields. Preserve missing metadata as absent, not an empty string. Restoration is an operator operation; this build has no remote blanket rollback endpoint.

## Deployment checks still required

- Your actual WordPress/PHP versions, object-cache backend, filesystem ownership and credentials.
- Multisite local/network-only activation, cross-subsite operations and chosen service-admin membership. Multisite was not exercised in this isolated single-site suite.
- Rank Math/Yoast and your production cache plugins, premium update providers, licensing and package delivery.
- Browser-rendered settings and actual HTTPS/CDN routing.
- Dashboard integration, retry persistence, tenant permissions and destination validation.
- Native/admin/CLI/background updater coordination and recovery from a forcibly terminated worker.
- A fresh-process health check after an update, plus real site functionality.

The automated tests use real WordPress core and MariaDB, with a local harmless fixture package and controlled update metadata. They do not call a live client's dashboard or update any live client plugin.

## Reference documentation

- https://developer.wordpress.org/reference/classes/plugin_upgrader/bulk_upgrade/
- https://developer.wordpress.org/reference/functions/activate_plugin/
- https://developer.wordpress.org/reference/functions/update_post_meta/
- https://developer.wordpress.org/reference/functions/wp_slash/

See `TEST-RESULTS.json` for exact automated checks and environment versions.
